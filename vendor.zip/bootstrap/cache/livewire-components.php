<?php return array (
  'footer' => 'App\\Http\\Livewire\\Footer',
  'laporan-progres' => 'App\\Http\\Livewire\\LaporanProgres',
  'mapping-regu' => 'App\\Http\\Livewire\\MappingRegu',
  'navbar' => 'App\\Http\\Livewire\\Navbar',
  'profile' => 'App\\Http\\Livewire\\Profile',
  'progres-work-order' => 'App\\Http\\Livewire\\ProgresWorkOrder',
  'sidebar' => 'App\\Http\\Livewire\\Sidebar',
  'user' => 'App\\Http\\Livewire\\User',
  'work-order' => 'App\\Http\\Livewire\\WorkOrder',
);