<div class="flex items-center justify-center px-2 py-3 mx-2 text-lg font-bold text-center text-white bg-gray-500 border border-gray-900">
    <h3>Sistem Informasi Monitoring Instalasi Pasang Baru Wifi ID PT Telkom Akses Witel Bali Selatan</h3>
</div>
