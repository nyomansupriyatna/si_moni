<div class="mt-5 h-screen">
    <div class="relative  flex h-full w-full justify-center px-3">

        <div class="border h-56 shadow-sm rounded bg-white p-5 mb-3">
            <h1 class="text-bold text-xl underline py-3">Profile User</h1>
            <table>
                <tr>
                    <td>User Name</td><td class="px-3">:</td><td><?php echo e(Auth::user()->username); ?></td>
                </tr>
                <tr>
                    <td>Display Name</td><td class="px-3">:</td><td><?php echo e(Auth::user()->nama); ?></td>
                </tr>
                <tr>
                    <td>Hak Akses</td><td class="px-3">:</td><td><?php echo e(Auth::user()->hak_akses); ?></td>
                </tr>
            </table>

            <?php if (isset($component)) { $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BtnSave::class, ['px' => 'px-5','title' => 'Change Password']); ?>
<?php $component->withName('btn-save'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'open_window','class' => 'mt-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b)): ?>
<?php $component = $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b; ?>
<?php unset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b); ?>
<?php endif; ?>
        </div>

        <?php if($open_chg_passw): ?>
            <div class="absolute flex justify-center inset-0 bg-gray-50">
                
                <div class="w-96 h-80 border border-gray-300 bg-white p-5 mx-3 rounded">
                    <h1 class="text-bold text-xl underline text-center mb-3">Change Password</h1>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['type' => 'password','label' => 'Current Password','name' => 'current_password']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['type' => 'password','label' => 'New Password','name' => 'new_password']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['type' => 'password','label' => 'Confirm Password','name' => 'confirm_password']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>

                    <div class="flex gap-2 justify-center py-3">
                        <div wire:click="close_window" class="border bg-black text-white cursor-pointer px-3 py-1 rounded-md"><< Back</div>
                        <div wire:click="changePassword" class="border bg-blue-500 text-white cursor-pointer px-3 py-1 rounded-md">Save</div>
                    </div>

                </div>
            </div>
        <?php endif; ?>

    </div>


</div>
<?php /**PATH D:\xampp\htdocs\laravel\si_moni\resources\views/livewire/profile.blade.php ENDPATH**/ ?>