<div class="flex-1">


    <div class="w-full px-2 overflow-x-scroll">
        <table class="w-full table-auto">
            <thead>
                <td colspan="<?php echo e(count($headers)+1); ?>">
                    <div class="block mb-1 bg-indigo-700 sm:flex">
                        <div class="p-2 w-42">
                            <select name="perPage" id="perPage"
                                class="flex border rounded cursor-pointer h-9 focus:outline-none focus:border-blue-500 focus:bg-white "
                                >
                                    <option value="3" class="flex items-center">5</option>
                                    <option value="10" class="flex items-center">10</option>
                                    <option value="25" class="flex items-center">25</option>
                                    <option value="50" class="flex items-center">50</option>
                                    <option value="100" class="flex items-center">100</option>
                            </select>
                        </div>
                        <div class="flex w-full px-3 py-2" >
                            <h2 class="items-center justify-start h-full font-bold text-white">Laporan Progress</h2>
                        </div>
                        <div class="flex w-full p-2 lg:justify-end lg:w-7/12">
                            <div class="relative">
                                <div class="absolute flex items-center h-full left-1">
                                    <?php if (isset($component)) { $__componentOriginald2cbd53f813b0d659f2269c5137bda62cd4d8ce9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\IconSearch::class, ['width' => '20','height' => '20']); ?>
<?php $component->withName('icon-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-gray-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald2cbd53f813b0d659f2269c5137bda62cd4d8ce9)): ?>
<?php $component = $__componentOriginald2cbd53f813b0d659f2269c5137bda62cd4d8ce9; ?>
<?php unset($__componentOriginald2cbd53f813b0d659f2269c5137bda62cd4d8ce9); ?>
<?php endif; ?>
                                </div>
                                <div wire:click="clearSearch" class="absolute flex items-center h-full cursor-pointer right-1">
                                    <?php if (isset($component)) { $__componentOriginalf9a0b8c3a596343d20889f0610523e40e370a432 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\IconCancel::class, ['width' => '24','height' => '24']); ?>
<?php $component->withName('icon-cancel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-gray-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9a0b8c3a596343d20889f0610523e40e370a432)): ?>
<?php $component = $__componentOriginalf9a0b8c3a596343d20889f0610523e40e370a432; ?>
<?php unset($__componentOriginalf9a0b8c3a596343d20889f0610523e40e370a432); ?>
<?php endif; ?>
                                </div>

                                <input wire:model.debounce.500ms="search"  type="text" placeholder="Search..."
                                    class="w-full pl-10 border border-gray-400 rounded h-9 pr-7 focus:outline-none focus:border-blue-500">
                            </div>
                        </div>
                    </div>
                </td>
            </thead>
            <thead class="px-3 font-bold text-indigo-700 bg-indigo-200">
                <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <th wire:click="sort('<?php echo e($key); ?>')" class="py-2 border border-gray-400 cursor-pointer w-min hover:bg-indigo-300 hover:text-indigo-900">
                        <div class="flex items-center justify-center gap-2">
                            <?php if($sortColumn == $key): ?>
                                    <?php if($sortDirection == 'asc'): ?>
                                        <?php if (isset($component)) { $__componentOriginala34eb0c6d14c1ff11aecd8ffe7e5854500163335 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\IconChevUp::class, []); ?>
<?php $component->withName('icon-chev-up'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-indigo-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala34eb0c6d14c1ff11aecd8ffe7e5854500163335)): ?>
<?php $component = $__componentOriginala34eb0c6d14c1ff11aecd8ffe7e5854500163335; ?>
<?php unset($__componentOriginala34eb0c6d14c1ff11aecd8ffe7e5854500163335); ?>
<?php endif; ?>
                                    <?php else: ?>
                                        <?php if (isset($component)) { $__componentOriginalf73d342ed8b8df807f7d348265e406a127fc90fd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\IconChevDown::class, []); ?>
<?php $component->withName('icon-chev-down'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-indigo-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf73d342ed8b8df807f7d348265e406a127fc90fd)): ?>
<?php $component = $__componentOriginalf73d342ed8b8df807f7d348265e406a127fc90fd; ?>
<?php unset($__componentOriginalf73d342ed8b8df807f7d348265e406a127fc90fd); ?>
<?php endif; ?>
                                    <?php endif; ?>
                            <?php endif; ?>
                            <?php echo e(is_array($value) ? $value['label'] : $value); ?>

                        </div>
                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </thead>
            <tbody>
                <?php if(count($data)): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-200">
                            <td class="px-2 border border-gray-300">
                                <?php echo e($item->tgl_update); ?>

                            </td>
                            <td class="px-2 border border-gray-300 w-max-content">
                                <?php echo e($item->user_psb); ?>

                            </td>
                            <td class="px-2 border border-gray-300 w-max-content">
                                <?php echo e($item->status); ?>

                            </td>
                            <td class="px-2 border border-gray-300 w-max-content">
                                <?php echo e($item->datek); ?>

                            </td>
                            <td class="px-2 text-center border border-gray-300 w-max-content">
                                <?php echo e($item->sn_modem); ?>

                            </td>
                            <td class="px-2 text-center border border-gray-300 w-max-content">
                                <?php echo e($item->jumlah_ap); ?>

                            </td>
                            <td class="px-2 text-center border border-gray-300 w-max-content">
                                <?php echo e($item->panjang_dc); ?>

                            </td>
                            <td class="px-2 text-center border border-gray-300 w-max-content">
                                <?php echo e($item->material_lain); ?>

                            </td>
                            <td class="px-2 text-center border border-gray-300 w-max-content">
                                <?php echo e($item->keterangan_tambahan); ?>

                            </td>
                            <td class="px-2 py-1 text-center border border-gray-300 w-max-content">
                                <?php if (isset($component)) { $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BtnSave::class, ['title' => 'FOTO']); ?>
<?php $component->withName('btn-save'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'open_fotos('.e($item->id).')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b)): ?>
<?php $component = $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b; ?>
<?php unset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b); ?>
<?php endif; ?>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="<?php echo e(count($headers)+1); ?>" class="text-center border border-gray-300" ><h2> No Result found...</h2></td>
                    </tr>
                <?php endif; ?>
            </tbody>

        </table>
    </div>
    <div class="justify-end mt-1">
            <?php echo e($data->links()); ?>

    </div>

    <?php if($isOpen): ?>
        <?php echo $__env->make('livewire.laporan-progres.fotos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</div>

<?php /**PATH C:\xampp\htdocs\laravel\si_moni\resources\views/livewire/laporan-progres/index.blade.php ENDPATH**/ ?>