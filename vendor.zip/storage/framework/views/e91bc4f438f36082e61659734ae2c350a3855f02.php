<!-- This example requires Tailwind CSS v2.0+ -->
<div class="fixed inset-0 z-10 overflow-y-auto">
  <div class="flex items-end justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">

    <div class="fixed inset-0 transition-opacity" aria-hidden="true">
      <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
    </div>

    <!-- This element is to trick the browser into centering the modal contents. -->
    <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

    <div class="inline-block overflow-hidden text-left align-bottom transition-all transform bg-white rounded-lg shadow-xl sm:my-8 sm:align-middle sm:max-w-lg sm:w-full" role="dialog" aria-modal="true" aria-labelledby="modal-headline">
      <div class="px-4 pt-5 pb-4 bg-white sm:p-6 sm:pb-4">
        <div class="mb-2 sm:flex sm:items-start">
          <div class="flex items-center justify-center flex-shrink-0 w-12 h-12 mx-auto bg-indigo-200 rounded-full sm:mx-0 sm:h-10 sm:w-10">
            <!-- Heroicon name: exclamation -->
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4"></path></svg>
          </div>
          <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
            <h3 class="pt-2 text-lg font-bold leading-6 text-indigo-500" id="modal-headline">
             <?php echo e($action_btn); ?> Record
            </h3>
            <div class="mt-2">
            </div>
          </div>
        </div>
        <hr/>
        <form action="">

        

        <div>
            <div class="my-2">

                <input class="mb-2" wire:model="user_id" class="w-full h-8 px-3 border border-gray-500 rounded" type="hidden" >
                <?php if($action_btn=='Edit'): ?>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'nik','label' => 'NIK','readonly' => 'readonly']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'username','label' => 'User Name','readonly' => 'readonly']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'nik','label' => 'NIK']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'username','label' => 'User Name']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'nama','label' => 'Nama']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'alamat','label' => 'Alamat']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>

                <select wire:model="jenis_kelamin" name="jenis_kelamin" class="block w-full px-3 border rounded text-md h-9">
                    <?php if($action_btn == 'Edit'): ?>
                        <option <?php echo e($jenis_kelamin == 'L' ? 'selected' : ''); ?> value="L">Laki-laki</option>
                        <option <?php echo e($jenis_kelamin == 'P' ? 'selected' : ''); ?> value="P">Perempuan</option>
                    <?php else: ?>
                        <option value="" disabled selected hidden>Pilih Jenis Kelamin</option>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    <?php endif; ?>
                </select>

                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'no_tlp','label' => 'No Telepon']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc7c1d96e0760e62ea7923f0dd875b824f15be106 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputCombo::class, ['name' => 'hak_akses','label' => 'Hak Akses','data' => $accessData,'field' => $hak_akses]); ?>
<?php $component->withName('input-combo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7c1d96e0760e62ea7923f0dd875b824f15be106)): ?>
<?php $component = $__componentOriginalc7c1d96e0760e62ea7923f0dd875b824f15be106; ?>
<?php unset($__componentOriginalc7c1d96e0760e62ea7923f0dd875b824f15be106); ?>
<?php endif; ?>

            </div>
            <div class="text-xs text-center text-red-400 ">
                default password adalah 123, password bisa diubah di user profile
            </div>
        </div>
        <?php echo $action_btn =='Delete' ?  '<h3 class="text-center text-red-500">Delete this record ?</h3>' : ''; ?>

      </div>
        <div class="px-4 py-3 bg-gray-100 sm:px-6 sm:flex sm:flex-row-reverse">
            <?php if($action_btn=='Delete'): ?>
                <?php if (isset($component)) { $__componentOriginalfdbc6292b941a00c09b252a9eebccd6339a52543 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BtnDelete::class, ['px' => 'px-4']); ?>
<?php $component->withName('btn-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => 'confirmDelete('.e($user_id).')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfdbc6292b941a00c09b252a9eebccd6339a52543)): ?>
<?php $component = $__componentOriginalfdbc6292b941a00c09b252a9eebccd6339a52543; ?>
<?php unset($__componentOriginalfdbc6292b941a00c09b252a9eebccd6339a52543); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if($action_btn=='Add'): ?>
                    <?php if (isset($component)) { $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BtnSave::class, ['px' => 'px-4 mb-2']); ?>
<?php $component->withName('btn-save'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => 'store()']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b)): ?>
<?php $component = $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b; ?>
<?php unset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b); ?>
<?php endif; ?>
                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BtnSave::class, ['title' => 'Update']); ?>
<?php $component->withName('btn-save'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => 'update('.e($user_id).')','class' => 'px-4 mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b)): ?>
<?php $component = $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b; ?>
<?php unset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b); ?>
<?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BtnCancel::class, ['px' => 'px-4']); ?>
<?php $component->withName('btn-cancel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'hideModal','class' => 'mr-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1)): ?>
<?php $component = $__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1; ?>
<?php unset($__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1); ?>
<?php endif; ?>
        </div>
    </form>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\si_moni\resources\views/livewire/user/create.blade.php ENDPATH**/ ?>