<div <?php echo e($attributes); ?>>
    <button type="<?php echo e($tipe); ?>" class="inline-flex justify-center w-full <?php echo e($px); ?> <?php echo e($py); ?> text-base font-medium text-white bg-<?php echo e($color); ?>-500 border border-transparent rounded-full shadow-sm hover:bg-<?php echo e($color); ?>-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-<?php echo e($color); ?>-400 sm:ml-0 sm:w-auto sm:text-sm">
        <div class="flex items-center justify-center gap-2">
            <?php if(!$icon==""): ?>
                <?php if (isset($component)) { $__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\DynamicComponent::class, ['component' => $icon]); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['width' => '20','height' => '20']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9)): ?>
<?php $component = $__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9; ?>
<?php unset($__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if(!$title==""): ?>
                <span class="<?php echo e(!$title == "" ? 'ml-1':''); ?> font-semibold"> <?php echo e($title); ?></span>
            <?php endif; ?>
        </div>
    </button>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\si_moni\resources\views/components/buttons/btn.blade.php ENDPATH**/ ?>