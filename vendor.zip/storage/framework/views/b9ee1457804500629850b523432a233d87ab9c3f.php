<div <?php echo e($attributes); ?>>
    <div class="px-2 mb-1 text-indigo-700 border-r rounded-l">
        <label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
    </div>
    <select wire:model="<?php echo e($name); ?>" name="<?php echo e($name); ?>" class="w-full text-sm border rounded h-9">
        <?php if($action_btn == 'edit'): ?>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->id == $field): ?>
                    <option selected value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php else: ?>

            <option class="flex items-center" value="" disabled selected hidden>Select <?php echo e($name); ?></option>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
    </select>
    <?php if($errors->has('<?php echo e($name); ?>')): ?>
        <span class="text-xs text-red-500" role="alert">
            <strong><?php echo e($errors->first($name)); ?></strong>
        </span>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\si_moni\resources\views/components/elements/input-combo.blade.php ENDPATH**/ ?>