<div <?php echo e($attributes); ?>>
    <button type="button" class="inline-flex justify-center w-full <?php echo e($px); ?> <?php echo e($py); ?> text-base font-medium text-white bg-green-500 border border-transparent rounded-full shadow-sm hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-400 sm:ml-0 sm:w-auto sm:text-sm">
        <div class="flex items-center justify-between">
            <?php if (isset($component)) { $__componentOriginal6c9c8f66c6e636b885119d13b01b22194266d89a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\IconSave::class, ['width' => '20','height' => '20']); ?>
<?php $component->withName('icon-save'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6c9c8f66c6e636b885119d13b01b22194266d89a)): ?>
<?php $component = $__componentOriginal6c9c8f66c6e636b885119d13b01b22194266d89a; ?>
<?php unset($__componentOriginal6c9c8f66c6e636b885119d13b01b22194266d89a); ?>
<?php endif; ?>
            <span class=" <?php echo e(!$title == "" ? 'ml-2':''); ?> font-semibold"> <?php echo e($title); ?></span>
        </div>
    </button>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\si_moni\resources\views/components/buttons/btn-save.blade.php ENDPATH**/ ?>