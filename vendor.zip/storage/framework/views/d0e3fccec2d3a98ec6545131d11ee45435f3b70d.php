<div <?php echo e($attributes); ?> class="tooltip">
    <?php if($tooltiptext !== ""): ?>
        <span class="tooltiptext"><?php echo e($tooltiptext); ?></span>
    <?php endif; ?>
    <button type="button" class="inline-flex justify-center w-full <?php echo e($px); ?> <?php echo e($py); ?> text-base font-medium text-white bg-purple-500 border border-transparent rounded-full shadow-sm hover:bg-purple-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-400 sm:ml-0 sm:w-auto sm:text-sm">
        <div class="flex items-center justify-between">
            <?php if (isset($component)) { $__componentOriginal8ebc2cfae60e7fda14142d5a384e1fb512120930 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\IconAdd::class, ['width' => '20','height' => '20']); ?>
<?php $component->withName('icon-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ebc2cfae60e7fda14142d5a384e1fb512120930)): ?>
<?php $component = $__componentOriginal8ebc2cfae60e7fda14142d5a384e1fb512120930; ?>
<?php unset($__componentOriginal8ebc2cfae60e7fda14142d5a384e1fb512120930); ?>
<?php endif; ?>
            <span class=" <?php echo e(!$title == "" ? 'ml-2':''); ?> font-semibold"> <?php echo e($title); ?></span>
        </div>
    </button>
</div>
<?php /**PATH D:\xampp\htdocs\laravel\si_moni\resources\views/components/buttons/btn-add.blade.php ENDPATH**/ ?>