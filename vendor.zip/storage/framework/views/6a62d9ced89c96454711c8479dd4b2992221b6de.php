 
 <div class="flex flex-col items-center justify-center gap-2 py-2 text-gray-700 border border-t border-gray-200 bg-gradient-to-t from-gray-300 to-gray-100">
     
    <div class="flex text-xs">Copyright © <?php echo e(date('Y')); ?></div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\si_moni\resources\views/livewire/inc/footer.blade.php ENDPATH**/ ?>