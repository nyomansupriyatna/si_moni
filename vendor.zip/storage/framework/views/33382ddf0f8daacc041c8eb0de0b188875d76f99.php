<div <?php echo e($attributes); ?>>
    <svg xmlns="http://www.w3.org/2000/svg"
        width="<?php echo e($width); ?>"
        height="<?php echo e($height); ?>"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
        class="feather feather-chevrons-up">
        <polyline points="17 11 12 6 7 11"></polyline>
        <polyline points="17 18 12 13 7 18"></polyline>
    </svg>
</div>
<?php /**PATH D:\xampp\htdocs\laravel\si_moni\resources\views/components/icons/icon-chev-up.blade.php ENDPATH**/ ?>