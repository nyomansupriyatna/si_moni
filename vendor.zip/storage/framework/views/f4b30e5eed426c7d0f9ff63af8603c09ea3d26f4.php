<div class="fixed inset-0 flex items-center justify-center pr-10 bg-gray-500 bg-opacity-75">

    <div class="w-auto p-3 bg-white bg-opacity-100 rounded shadow-sm">
        <h1 class="block py-2 mb-2 text-center bg-gray-200 font-2xl">FOTO (STATUS : <?php echo e(strtoupper($status)); ?>)</h1>

        <div class="flex items-center justify-center gap-2">
            <?php if($status=='ok'): ?>
                <div class="flex-1">
                    <img  class="overflow-hidden w-80 " src="/storage/images/<?php echo e($foto_odp); ?>">
                    <span class="block text-center text-white bg-gray-700">Foto ODP</span>

                </div>
                <div class="flex-1">
                    <img  class="overflow-hidden w-80 " src="/storage/images/<?php echo e($foto_rumah_pelanggan); ?>">
                    <span class="block text-center text-white bg-gray-700">Rumah Pelanggan</span>
                </div>
                <div class="flex-1">
                    <img  class="overflow-hidden w-80 " src="/storage/images/<?php echo e($foto_modem); ?>">
                    <span class="block text-center text-white bg-gray-700">Foto Modem</span>
                </div>
                <div class="flex-1">
                    <img  class="overflow-hidden w-80 " src="/storage/images/<?php echo e($foto_ap); ?>">
                    <span class="block text-center text-white bg-gray-700">Foto AP</span>
                </div>
            <?php elseif($status=='kendala'): ?>
                <div class="flex-1">
                    <img  class="overflow-hidden w-80 " src="/storage/images/<?php echo e($foto_kendala); ?>">
                    <span class="block text-center text-white bg-gray-700">Foto Kendala</span>
                </div>
            <?php else: ?>
            <?php endif; ?>

        </div>
        <div class="block p-3 text-center">
            <?php if (isset($component)) { $__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BtnCancel::class, ['title' => 'Close Foto']); ?>
<?php $component->withName('btn-cancel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'close_fotos()']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1)): ?>
<?php $component = $__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1; ?>
<?php unset($__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\laravel\si_moni\resources\views/livewire/laporan-progres/fotos.blade.php ENDPATH**/ ?>