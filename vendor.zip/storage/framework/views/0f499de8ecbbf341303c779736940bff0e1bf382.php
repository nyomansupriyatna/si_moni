<div <?php echo e($attributes); ?>>
    <svg xmlns="http://www.w3.org/2000/svg"
        width="<?php echo e($width); ?>"
        height="<?php echo e($height); ?>"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
        class="feather feather-chevrons-down">
        <polyline points="7 13 12 18 17 13"></polyline>
        <polyline points="7 6 12 11 17 6"></polyline>
    </svg>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\si_moni\resources\views/components/icons/icon-chev-down.blade.php ENDPATH**/ ?>