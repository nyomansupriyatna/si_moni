<!-- This example requires Tailwind CSS v2.0+ -->
<div class="fixed inset-0 z-10 overflow-y-auto">
  <div class="flex items-end justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">

    <div class="fixed inset-0 transition-opacity" aria-hidden="true">
      <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
    </div>

    <!-- This element is to trick the browser into centering the modal contents. -->
    <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

    <div class="inline-block overflow-hidden text-left align-bottom transition-all transform bg-white rounded-lg shadow-xl sm:my-8 sm:align-middle sm:max-w-lg sm:w-full" role="dialog" aria-modal="true" aria-labelledby="modal-headline">
      <div class="px-4 pt-5 pb-4 bg-white sm:p-6 sm:pb-4">
        <div class="mb-2 sm:flex sm:items-start">
          <div class="flex items-center justify-center flex-shrink-0 w-12 h-12 mx-auto bg-indigo-200 rounded-full sm:mx-0 sm:h-10 sm:w-10">
            <!-- Heroicon name: exclamation -->
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4"></path></svg>
          </div>
          <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
            <h3 class="pt-2 text-lg font-bold leading-6 text-indigo-500" id="modal-headline">
             <?php echo e($action_btn); ?> Record
            </h3>
            <div class="mt-2">
            </div>
          </div>
        </div>
        <hr/>
        <form action="">

        

        <div>
            <div class="my-2">
                <input class="mb-2" wire:model="wo_id" class="w-full h-8 px-3 border border-gray-500 rounded" type="hidden" >

                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'tanggal','label' => 'User PSB','type' => 'date']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'user_psb','label' => 'User PSB','readonly' => 'readonly']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>

                <label for="status">Status</label>
                <select wire:model="status" name="status" class="w-full text-sm border rounded h-9">
                    <option class="flex items-center" value="null" disabled selected hidden>--select--</option>
                    <?php $__currentLoopData = $all_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <span class="mb-2 text-xs text-red-500 " role="alert">
                        <strong><?php echo e($errors->first('status')); ?></strong>
                    </span>
                <?php endif; ?>

                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'datek','label' => 'Date ODP','readonly' => 'readonly']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'sn_modem','label' => 'SN Modem']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'jumlah_ap','label' => 'Jumlah AP','type' => 'number']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'panjang_dc','label' => 'Panjang DC','type' => 'number']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'material_lain','label' => 'Material Lain']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'keterangan_tambahan','label' => 'Keterangan Tambahan']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if($status == 'ok'): ?>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'foto_odp','label' => 'Foto ODP','type' => 'file']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'foto_rumah_pelanggan','label' => 'Foto Rumah Pelanggan','type' => 'file']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'foto_modem','label' => 'Foto Modem','type' => 'file']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'foto_ap','label' => 'Foto Ap','type' => 'file']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php elseif($status == 'kendala'): ?>
                    <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['name' => 'foto_kendala','label' => 'Foto Kendala','type' => 'file']); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php else: ?>
                <?php endif; ?>

            </div>

        </div>
        <?php echo $action_btn =='Delete' ?  '<h3 class="text-center text-red-500">Delete this record ?</h3>' : ''; ?>

      </div>
        <div class="px-4 py-3 bg-gray-100 sm:px-6 sm:flex sm:flex-row-reverse">
            <?php if($action_btn=='Delete'): ?>
                <?php if (isset($component)) { $__componentOriginalfdbc6292b941a00c09b252a9eebccd6339a52543 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BtnDelete::class, ['px' => 'px-4']); ?>
<?php $component->withName('btn-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => 'confirmDelete('.e($wo_id).')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfdbc6292b941a00c09b252a9eebccd6339a52543)): ?>
<?php $component = $__componentOriginalfdbc6292b941a00c09b252a9eebccd6339a52543; ?>
<?php unset($__componentOriginalfdbc6292b941a00c09b252a9eebccd6339a52543); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if($action_btn=='Add'): ?>
                    <?php if (isset($component)) { $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BtnSave::class, ['px' => 'px-4 mb-2']); ?>
<?php $component->withName('btn-save'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => 'store()']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b)): ?>
<?php $component = $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b; ?>
<?php unset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b); ?>
<?php endif; ?>
                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BtnSave::class, ['title' => 'Update']); ?>
<?php $component->withName('btn-save'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => 'update('.e($wo_id).')','class' => 'px-4 mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b)): ?>
<?php $component = $__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b; ?>
<?php unset($__componentOriginal4bf542f0ea6b42d1f9e80afe07fa51ed627c5e4b); ?>
<?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BtnCancel::class, ['px' => 'px-4']); ?>
<?php $component->withName('btn-cancel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'hideModal','class' => 'mr-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1)): ?>
<?php $component = $__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1; ?>
<?php unset($__componentOriginale04e6f89b5b19af383810db2dcbde5f30eeb3fa1); ?>
<?php endif; ?>
        </div>
    </form>
    </div>
  </div>
</div>
<?php /**PATH D:\xampp\htdocs\laravel\si_moni\resources\views/livewire/progres-work-order/create.blade.php ENDPATH**/ ?>