<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes = $attributes->exceptProps(['width','height']); ?>
<?php foreach (array_filter((['width','height']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal4ad53f55b2ac8b393876b0427b16b35c8c8f6641 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\IconUser::class, ['width' => $width,'height' => $height]); ?>
<?php $component->withName('icon-user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ad53f55b2ac8b393876b0427b16b35c8c8f6641)): ?>
<?php $component = $__componentOriginal4ad53f55b2ac8b393876b0427b16b35c8c8f6641; ?>
<?php unset($__componentOriginal4ad53f55b2ac8b393876b0427b16b35c8c8f6641); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\si_moni\storage\framework\views/a84fc2034b2ff918e1ad10f32bb72a737a258ae8.blade.php ENDPATH**/ ?>