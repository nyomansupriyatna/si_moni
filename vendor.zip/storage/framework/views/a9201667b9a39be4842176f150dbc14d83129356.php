<div <?php echo e($attributes); ?>>
    <div class="relative">
        <label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
        <div>
            <input <?php echo e($status !== 'opn' ? 'disabled':''); ?> wire:model="<?php echo e($name); ?>" name="<?php echo e($name); ?>" class="w-full h-8 px-3 border rounded pl-7 " type="<?php echo e($type); ?>" placeholder="<?php echo e($label); ?>..." <?php echo e($readonly); ?>>
        </div>

        <?php if($errors->has($name)): ?>
            <span class="text-xs text-red-500" role="alert">
                <strong><?php echo e($errors->first($name)); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\laravel\si_moni\resources\views/components/elements/input-text.blade.php ENDPATH**/ ?>