<div <?php echo e($attributes); ?>>
    <button type="button" class="inline-flex justify-center w-full <?php echo e($px); ?> <?php echo e($py); ?> text-base font-medium text-white bg-yellow-500 border border-transparent rounded-full shadow-sm hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-400 sm:ml-0 sm:w-auto sm:text-sm">
        <div class="flex items-center justify-between">
            <?php if (isset($component)) { $__componentOriginalf9a0b8c3a596343d20889f0610523e40e370a432 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\IconCancel::class, ['width' => '20','height' => '20']); ?>
<?php $component->withName('icon-cancel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9a0b8c3a596343d20889f0610523e40e370a432)): ?>
<?php $component = $__componentOriginalf9a0b8c3a596343d20889f0610523e40e370a432; ?>
<?php unset($__componentOriginalf9a0b8c3a596343d20889f0610523e40e370a432); ?>
<?php endif; ?>
            <span class="<?php echo e(!$title == "" ? 'ml-2':''); ?> font-semibold"> <?php echo e($title); ?></span>
        </div>
    </button>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\si_moni\resources\views/components/buttons/btn-cancel.blade.php ENDPATH**/ ?>