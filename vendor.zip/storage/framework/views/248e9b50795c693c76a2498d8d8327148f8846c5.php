<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes = $attributes->exceptProps(['width','height']); ?>
<?php foreach (array_filter((['width','height']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal40954974cf078650e7e0d7cb1a6b2e3181a4799b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\IconEmail::class, ['width' => $width,'height' => $height]); ?>
<?php $component->withName('icon-email'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40954974cf078650e7e0d7cb1a6b2e3181a4799b)): ?>
<?php $component = $__componentOriginal40954974cf078650e7e0d7cb1a6b2e3181a4799b; ?>
<?php unset($__componentOriginal40954974cf078650e7e0d7cb1a6b2e3181a4799b); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\si_moni\storage\framework\views/80fd7d26359b65ae493aa321e65cbbdd629ded1a.blade.php ENDPATH**/ ?>