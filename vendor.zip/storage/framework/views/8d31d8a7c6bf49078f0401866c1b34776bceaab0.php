<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel 8')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="<?php echo e(asset('js/sn.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery_351.js')); ?>"></script>
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>

        <style>
            /* Tooltip container */
            .tooltip {
              position: relative;
              display: inline-block;
              border-bottom: 0px; /* If you want dots under the hoverable text */
            }

            /* Tooltip text */
            .tooltip .tooltiptext {
                display:block;
                visibility: hidden;
                width: 80px;
                background-color: white;
                color: gray;
                text-align: center;
                padding: 3px 0;
                border-radius: 10px;
                font-size: 12px;

                bottom: 100%;
                left: 50%;
                margin-left: -40px; /* Use half of the width (120/2 = 60), to center the tooltip */

                /* Position the tooltip text - see examples below! */
                position: absolute;
                z-index: 1;
            }

            /* Show the tooltip text when you mouse over the tooltip container */
            .tooltip:hover .tooltiptext {
                transition-delay: 2s;
                visibility: visible;
            }
        </style>

        <!-- Scripts -->
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    </head>
    <body class="font-sans antialiased">
        <div class="bg-gray-50">
            <main class="relative flex flex-col min-h-screen mt-16 sm:flex-row" >
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sidebar')->html();
} elseif ($_instance->childHasBeenRendered('ITnMsh0')) {
    $componentId = $_instance->getRenderedChildComponentId('ITnMsh0');
    $componentTag = $_instance->getRenderedChildComponentTagName('ITnMsh0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ITnMsh0');
} else {
    $response = \Livewire\Livewire::mount('sidebar');
    $html = $response->html();
    $_instance->logRenderedChild('ITnMsh0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <div class="flex flex-col flex-1">
                    <?php echo $__env->make('livewire.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo e($slot); ?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer')->html();
} elseif ($_instance->childHasBeenRendered('P68x1DG')) {
    $componentId = $_instance->getRenderedChildComponentId('P68x1DG');
    $componentTag = $_instance->getRenderedChildComponentTagName('P68x1DG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('P68x1DG');
} else {
    $response = \Livewire\Livewire::mount('footer');
    $html = $response->html();
    $_instance->logRenderedChild('P68x1DG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </main>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navbar')->html();
} elseif ($_instance->childHasBeenRendered('ab81J5o')) {
    $componentId = $_instance->getRenderedChildComponentId('ab81J5o');
    $componentTag = $_instance->getRenderedChildComponentTagName('ab81J5o');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ab81J5o');
} else {
    $response = \Livewire\Livewire::mount('navbar');
    $html = $response->html();
    $_instance->logRenderedChild('ab81J5o', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>

        <script src="https://cdn.jsdelivr.net/gh/livewire/turbolinks@v0.1.x/dist/livewire-turbolinks.js" data-turbolinks-eval="false" data-turbo-eval="false"></script>
    </body>
</html>

<?php /**PATH C:\xampp\htdocs\laravel\si_moni\resources\views/layouts/app.blade.php ENDPATH**/ ?>